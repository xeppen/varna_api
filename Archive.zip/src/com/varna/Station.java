package com.varna;

public class Station {
	String station = "";
	String town = "";
	String type = "";
	String line = "";
	
	public String getStation() {
		return station;
	}
	public String getTown() {
		return town;
	}
	public void setStation(String station) {
		this.station = station;
	}
	public void setTown(String town) {
		this.town = town;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getLine() {
		return line;
	}
	public void setLine(String line) {
		this.line = line;
	}
	
	
}
